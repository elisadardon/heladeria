

<?php $__env->startSection('title', 'Clientes'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Crear cliente</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <a 
        href="<?php echo e(route('clientes.index')); ?>"
        class="btn btn-sm btn-primary"
    >
        Regresar
    </a>

    <?php if(session('error')): ?>
        <div class="alert alert-danger mt-3" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('clientes.store')); ?>" method="POST" class="mt-3">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="nombre">Nombre *</label>
            <input 
                type="text"
                id="nombre"
                name="nombre"
                class="form-control"
            >
        </div>
        <div class="mb-3">
            <label for="correo">Correo *</label>
            <input 
                type="email"
                id="correo"
                name="correo"
                class="form-control"
            >
        </div>
        <div class="mb-3">
            <label for="telefono">Telefono *</label>
            <input 
                type="text"
                id="telefono"
                name="telefono"
                class="form-control"
            >
        </div>
        <button
            type="submit"
            class="btn btn-sm btn-success"
        >
            Guardar
        </button>
        
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\heladeria\resources\views/clientes/create.blade.php ENDPATH**/ ?>