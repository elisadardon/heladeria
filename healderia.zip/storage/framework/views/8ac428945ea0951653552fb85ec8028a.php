

<?php $__env->startSection('title', 'Sabores'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Crear sabores</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <a 
        href="<?php echo e(route('sabores.index')); ?>"
        class="btn btn-sm btn-primary"
        >
        Regresar
    </a>

    <?php if(session('error')): ?>
        <div class="alert alert-danger mt-3" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('sabores.update', $sabor)); ?>" method="POST" class="mt-3">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="nombre">Nombre *</label>
            <input 
                type="text"
                id="nombre"
                name="nombre"
                class="form-control"
                value="<?php echo e($sabor->nombre); ?>"
            >
        </div>
        <div class="mb-3">
            <label for="descripcion">Descripcion *</label>
            <input 
                type="text"
                id="descripcion"
                name="descripcion"
                class="form-control"
                value="<?php echo e($sabor->descripcion); ?>"
            >
        </div>
        <div class="mb-3">
            <label for="precio">Precio *</label>
            <input 
                type="number"
                id="precio"
                name="precio"
                class="form-control"
                step="0.01"
                value="<?php echo e($sabor->precio); ?>"
            >
        </div>
        <button
            type="submit"
            class="btn btn-sm btn-success"
        >
            Guardar
        </button>
        
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\heladeria\resources\views/sabores/edit.blade.php ENDPATH**/ ?>