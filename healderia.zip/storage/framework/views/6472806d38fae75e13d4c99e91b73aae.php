

<?php $__env->startSection('title', 'Sabores'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Sabores</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <a 
        href="<?php echo e(route('sabores.create')); ?>"
        class="btn btn-sm btn-primary"
    >
        Crear
    </a>

    <?php if(session('success')): ?>
        <div class="alert alert-success mt-3" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table class="table mt-3">
        <thead class="table-dark">
            <tr>
                <td>Nombre</td>
                <td>Descripcion</td>
                <td>Precio</td>
                <td></td>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $sabores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sabor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($sabor->nombre); ?></td>
                    <td><?php echo e($sabor->descripcion); ?></td>
                    <td>Q.<?php echo e($sabor->precio); ?></td>
                    <td>
                        <div class="d-inline">
                            <a href="<?php echo e(route('sabores.edit', $sabor)); ?>" class="btn btn-sm btn-warning">
                                <i class="fas fa-pencil-alt"></i>
                            </a>
                            <form action="<?php echo e(route('sabores.destroy', $sabor->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('¿Estás seguro de que deseas eliminar el registro?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </form>
                        </div>
                    </td>                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="text-center">Sin resultados</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\heladeria\resources\views/sabores/index.blade.php ENDPATH**/ ?>