

<?php $__env->startSection('title', 'Pedidos | Nuevo pedido'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Nuevo Pedido</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success mt-3" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger mt-3" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    
    <form action="<?php echo e(route('agregarItem.index')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="id_sabor">Sabor *</label>
            <select name="id_sabor" id="id_sabor" class="form-control">
                <?php $__empty_1 = true; $__currentLoopData = $sabores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sabor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($sabor->id); ?>"><?php echo e($sabor->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    Sin resultados
                <?php endif; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="cantidad">Cantidad *</label>
            <input 
                type="text"
                id="cantidad"
                name="cantidad"
                class="form-control"
            >
        </div>
        <button type="submit" class="btn btn-sm btn-success">
            Agregar
        </button>
    </form>

    <div class="mt-3">
        <h1>Detalle del pedido</h1>

        <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#staticBackdrop">
            Finalizar pedido
        </button>
    </div>
    <table class="table mt-3">
        <thead class="table-dark">
            <tr>
                <td>Sabor</td>
                <td>Precio</td>
                <td>Cantidad</td>
                <td>Subtotal</td>
                <td></td>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($detalle->name); ?></td>
                    <td>Q.<?php echo e($detalle->price); ?></td>
                    <td><?php echo e($detalle->qty); ?></td>
                    <td>Q.<?php echo e($detalle->subtotal); ?></td>
                    <td>
                        <form action="<?php echo e(route('eliminarItem', $detalle->rowId)); ?>" method="POST" class="d-inline" onsubmit="return confirm('¿Estás seguro de que deseas eliminar el registro?');">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-sm btn-danger">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </form>
                    </td>                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center">Sin resultados</td>
                </tr>
            <?php endif; ?>
        </tbody>
        <?php if(Cart::content()->count()): ?>
            <tfoot>
                <tr>
                    <td colspan="3" class="text-right">Subtotal:</td>
                    <td><?php echo e(Cart::subtotal()); ?></td>
                </tr>
            </tfoot>
        <?php endif; ?>
    </table>

    <!-- Modal -->
    <div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="staticBackdropLabel">Finalizar pedido</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('finalizarPedido')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="id_cliente">Cliente *</label>
                        <select name="id_cliente" id="id_cliente" class="form-control">
                            <?php $__empty_1 = true; $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                Sin resultados
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="total">Total *</label>
                        <input type="text" class="form-control" id="total" name="total" value="<?php echo e(Cart::subtotal()); ?>" readonly>
                    </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-success">Guardar</button>
                    </div>
                </form>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\elisa\Downloads\heladeria\resources\views/pedidos/nuevo-pedido/index.blade.php ENDPATH**/ ?>