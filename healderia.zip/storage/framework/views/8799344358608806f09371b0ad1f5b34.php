

<?php $__env->startSection('title', 'Pedidos | Consulta pedidos'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Pedidos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <a 
        href="<?php echo e(route('DetallePedidos.index')); ?>"
        class="btn btn-sm btn-primary"
    >
        Crear
    </a>

    <?php if(session('success')): ?>
        <div class="alert alert-success mt-3" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table class="table mt-3">
        <thead class="table-dark">
            <tr>
                <td>Cliente</td>
                <td>Telefono</td>
                <td>Total</td>
                <td>Fecha pedido</td>
                <td></td>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($pedido->cliente->nombre); ?></td>
                    <td><?php echo e($pedido->cliente->telefono); ?></td>
                    <td>Q.<?php echo e($pedido->total); ?></td>
                    <td><?php echo e(date('d-m-Y H:i:s', strtotime($pedido->created_at))); ?></td>
                    <td>
                        <div class="d-inline">
                            <a href="<?php echo e(route('pedidos.view', $pedido)); ?>" class="btn btn-sm btn-warning">
                                <i class="far fa-eye"></i>
                            </a>
                        </div>
                    </td>                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center">Sin resultados</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\elisa\Downloads\heladeria\resources\views/pedidos/consulta-pedidos/index.blade.php ENDPATH**/ ?>