

<?php $__env->startSection('title', 'Pedido | Consulta pedidos'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Pedido</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <ul>
            <li>
                <label for="fecha_venta">Fecha:</label>
                <?php echo e(date('d-m-Y H:i:s', strtotime($pedido->created_at))); ?>

            </li>
            <li>
                <label for="nombre_cliente">Cliente:</label>
                <?php echo e($pedido->cliente->nombre); ?>

            </li>
            <li>
                <label for="total_venta">Total venta:</label>
                Q.<?php echo e($pedido->total); ?>

            </li>
        </ul>

        <div class="mt-3">
            <table class="table">
                <thead class="table-dark">
                    <tr>
                        <td>Sabor</td>
                        <td>Precio</td>
                        <td>Cantidad</td>
                        <td>Subtotal</td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($detalle->sabor->nombre); ?></td>
                            <td>Q.<?php echo e($detalle->sabor->precio); ?></td>
                            <td><?php echo e($detalle->cantidad); ?></td>
                            <td>Q.<?php echo e($detalle->sabor->precio * $detalle->cantidad); ?></td>                  
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center">Sin resultados</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3" class="text-right">Subtotal:</td>
                        <td><?php echo e($pedido->total); ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\elisa\Downloads\heladeria\resources\views/pedidos/consulta-pedidos/view.blade.php ENDPATH**/ ?>